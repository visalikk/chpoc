    angular.module('comApp',[])
            .controller('compController', ['$scope','$http', function($scope,$http) {
                $scope.companyhouse={};
                $scope.appointmentdata={};
                $scope.companyInfo=false;
                $scope.getData=function () {                  
                    alert($scope.comp_id);
                    $http.get("http://localhost:3000/company/"+ $scope.comp_id).then(function success(response) {
                      $scope.companyhouse=response.data;                      
                      console.log(response.data);
                    },function errorCallBack(response){
                      alert("Unable");
                          });



                        

    };

    $scope.getInfo=function (appointmenturl) {
      var aurllength = appointmenturl.length;      
      var appointmentId = appointmenturl.substring(10,(aurllength-13));      
      
      $http.get("http://localhost:3001/appointment/"+appointmentId).then(function success(response) {
                      $scope.appointmentdata=response.data; 
                      console.log("Success");
                      $scope.companyInfo=true;                     
                      
                    },function errorCallBack(response){
                      alert("Unable");
                          });

    }

    $scope.closePopup = function(){
         $scope.companyInfo=false;
    }

          
   }]);